const express = require("express");
const dotenv = require("dotenv");
const connectDB = require("./config/db");
const cors = require("cors"); // ✅ ADD THIS

dotenv.config();
connectDB();

const app = express();

// ✅ MIDDLEWARE
app.use(cors()); // ✅ ADD THIS
app.use(express.json());

// ✅ ROUTES
app.use("/api/auth", require("./routes/auth"));

app.get("/", (req, res) => {
  res.send("API Running...");
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));