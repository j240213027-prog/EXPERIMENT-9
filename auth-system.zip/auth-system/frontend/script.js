const API = "http://localhost:5000/api/auth";

// 🔄 SWITCH FORMS
function showRegister() {
  document.getElementById("loginForm").classList.add("hidden");
  document.getElementById("registerForm").classList.remove("hidden");
}

function showLogin() {
  document.getElementById("registerForm").classList.add("hidden");
  document.getElementById("loginForm").classList.remove("hidden");
}


// 🔐 REGISTER
async function register() {
  const name = document.getElementById("regName").value;
  const email = document.getElementById("regEmail").value;
  const password = document.getElementById("regPassword").value;

  const res = await fetch(`${API}/register`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name, email, password })
  });

  const data = await res.json();
  alert(data.msg);

  showLogin();
}


// 🔐 LOGIN
async function login() {
  const email = document.getElementById("loginEmail").value;
  const password = document.getElementById("loginPassword").value;

  const res = await fetch(`${API}/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password })
  });

  const data = await res.json();

  if (data.token) {
    localStorage.setItem("token", data.token);

    document.getElementById("authBox").style.display = "none";
    document.getElementById("dashboard").classList.remove("hidden");
  } else {
    alert(data.msg);
  }
}


// 🔒 PROTECTED ROUTE
async function getDashboard() {
  const token = localStorage.getItem("token");

  const res = await fetch(`${API}/dashboard`, {
    headers: {
      "Authorization": token
    }
  });

  const data = await res.json();

  // 🔥 SET USER DATA
  document.getElementById("welcome").innerText = `Welcome, ${data.name} 👋`;
  document.getElementById("userEmail").innerText = data.email;
}

// 🚪 LOGOUT
function logout() {
  localStorage.removeItem("token");

  document.getElementById("dashboard").classList.add("hidden");
  document.getElementById("authBox").style.display = "flex";
}